# cashflow.site backend (Python / Flask)

Members register, pay the access fee by M-Pesa, and are approved. The admin (Hakim Ray) signs in to
approve payments, manage members and see insight charts.

## What is included
- Member sign-up and sign-in (passwords hashed), payment submission, status page
- Admin sign-in (rate limited), payments approve/reject, members search and suspend, settings, audit log, CSV export
- Insights dashboard: members, conversion, revenue, approval time, signups/revenue per day, status charts
- Optional automatic confirmation with the Safaricom Daraja STK push
- CSRF protection, secure cookies, parameterised SQL, duplicate M-Pesa code blocking

## Run on your computer
```
pip install -r requirements.txt
python -c "from werkzeug.security import generate_password_hash as g; print(g(input('New admin password: ')))"
export ADMIN_PASSWORD_HASH='paste-the-output'   # Windows: set ADMIN_PASSWORD_HASH=...
export SECRET_KEY=$(python -c "import secrets;print(secrets.token_hex(32))")
export COOKIE_SECURE=0                           # local http only
python app.py            # open http://127.0.0.1:5000  and /admin
flask --app app seed-demo   # optional: fake demo data to preview the charts
```
Admin email defaults to chirchirlamec@gmail.com (change with ADMIN_EMAIL). There is no default password: sign-in stays
disabled until ADMIN_PASSWORD_HASH is set.

## Deploy (Render, easiest)
1. Put this folder in a GitHub repository (files at the top level, `app.py` included).
2. On render.com choose New, Blueprint (or Web Service) and pick the repository. `render.yaml` is ready.
3. Set ADMIN_PASSWORD_HASH in the Render dashboard (generate it with the command above).
4. The database is a SQLite file. Free web services lose local files on redeploy, so use a Render disk
   (in `render.yaml`, paid) or move the data to a hosted database such as Postgres before real members join.

## Payments
Open Admin, Settings, and enter the fee and the number members pay (a registered Till or Paybill is best).
Nothing is preset. With no Daraja settings, members pay by M-Pesa and submit the code; you approve after matching
the code, amount and phone to the SMS on your own phone.

For automatic confirmation, register at developer.safaricom.co.ke, then set DARAJA_* and CALLBACK_* from `.env.example`.
The STK push code is written to the Daraja documentation but was not run against Safaricom. Test it in the sandbox
first. Safaricom's callback must reach a public https address.

## Before launch
- Keep Terms, Privacy and contact pages, and the plain wording that the fee is for access and rewards are not guaranteed.
- You collect names and phone numbers, so follow the Kenya Data Protection Act (register with the ODPC if required).
- Back up the database and rotate the admin password.
- Run `python -m pytest test_app.py` after any change.
